<?php
/**
 * CHATBOT
 *
 * Genel yönlendirme ve tekil ders sayfalarında bağlama duyarlı AI yardımcısı.
 * You.com anahtarı yalnızca sunucuda okunur; tarayıcıya gönderilmez.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function ewt_render_chatbot() {
	$contact_enabled = ewt_campus_options()['contact_enabled'] === '1';
	$phone = get_option( 'ewt_tutoring_phone', '+90 530 571 40 67' );
	$wa = ewt_campus_wa();
	$greet = get_option( 'ewt_chatbot_greeting', "Merhaba! 👋 English Web TR'ye hoş geldin. Sana nasıl yardımcı olabilirim?" );
	?>
	<div id="ewt-chatbot" aria-live="polite">
		<button id="ewt-chatbot-toggle" aria-label="Sohbeti aç/kapat">
			<span class="ewt-chat-icon">💬</span>
		</button>
		<div id="ewt-chatbot-panel" class="ewt-hidden">
			<div class="ewt-chatbot-header">
				<span>English Web TR Asistan</span>
				<button id="ewt-chatbot-close" aria-label="Kapat">✕</button>
			</div>
			<div id="ewt-chatbot-messages">
				<div class="ewt-msg ewt-bot"><?php echo esc_html( $greet ); ?></div>
			</div>
			<div id="ewt-chatbot-quick-replies"></div>
			<form id="ewt-chatbot-question" class="ewt-hidden">
				<label for="ewt-chatbot-input">Bu paragrafla ilgili sorun nedir?</label>
				<div class="ewt-chatbot-input-row">
					<textarea id="ewt-chatbot-input" maxlength="500" rows="2" placeholder="Sorunu buraya yaz..."></textarea>
					<button type="button" id="ewt-chatbot-mic" aria-label="Soruyu sesle yaz" title="Soruyu sesle yaz">🎤</button>
					<button type="submit" id="ewt-chatbot-send">Gönder</button>
				</div>
				<p id="ewt-chatbot-voice-status" class="ewt-chatbot-status" aria-live="polite"></p>
			</form>
			<?php if ( $contact_enabled ) : ?><div class="ewt-chatbot-footer">
				<a href="tel:<?php echo esc_attr( $phone ); ?>" class="ewt-chatbot-cta ewt-call">📞 Ara</a>
				<a href="https://wa.me/<?php echo esc_attr( $wa ); ?>" target="_blank" rel="noopener" class="ewt-chatbot-cta ewt-wa">WhatsApp</a>
			</div><?php endif; ?>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'ewt_render_chatbot' );

/** Ziyaretçi başına basit saatlik maliyet koruması. */
function ewt_lesson_assistant_rate_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	return 'ewt_lesson_help_' . hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) );
}

function ewt_ajax_lesson_assistant() {
	if ( ! check_ajax_referer( 'ewt_lesson_assistant', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'Oturum doğrulanamadı. Lütfen sayfayı yenileyin.' ), 403 );
	}

	$rate_key = ewt_lesson_assistant_rate_key();
	$used     = (int) get_transient( $rate_key );
	if ( $used >= 10 ) {
		wp_send_json_error( array( 'message' => 'Saatlik yardım sınırına ulaştınız. Bir süre sonra yeniden deneyin.' ), 429 );
	}

	$action_type = isset( $_POST['request_type'] ) ? sanitize_key( wp_unslash( $_POST['request_type'] ) ) : 'question';
	$context     = isset( $_POST['context'] ) ? sanitize_textarea_field( wp_unslash( $_POST['context'] ) ) : '';
	$question    = isset( $_POST['question'] ) ? sanitize_textarea_field( wp_unslash( $_POST['question'] ) ) : '';
	$title       = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
	$post_id     = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;

	$context  = function_exists( 'mb_substr' ) ? mb_substr( $context, 0, 1800 ) : substr( $context, 0, 1800 );
	$question = function_exists( 'mb_substr' ) ? mb_substr( $question, 0, 500 ) : substr( $question, 0, 500 );
	$title    = function_exists( 'mb_substr' ) ? mb_substr( $title, 0, 180 ) : substr( $title, 0, 180 );

	if ( ! in_array( $action_type, array( 'examples', 'question' ), true ) || strlen( $context ) < 20 ) {
		wp_send_json_error( array( 'message' => 'Yardım için yeterli paragraf bağlamı bulunamadı.' ), 400 );
	}
	if ( $action_type === 'question' && strlen( $question ) < 3 ) {
		wp_send_json_error( array( 'message' => 'Lütfen sorunuzu biraz daha ayrıntılı yazın.' ), 400 );
	}
	if ( ! $post_id || get_post_status( $post_id ) !== 'publish' ) {
		wp_send_json_error( array( 'message' => 'Bu içerik yardım için uygun değil.' ), 400 );
	}

	$system = 'Sen English Web TR sitesinin sabırlı İngilizce öğretmenisin. Yalnızca verilen ders başlığı ve paragraf bağlamına dayan. Türkçe, kısa, anlaşılır ve öğrencinin seviyesine uygun yanıt ver. Gerektiğinde İngilizce örneklerin hemen ardından Türkçe anlamlarını yaz. Bilmediğin veya bağlamda olmayan bir noktayı uydurma. Markdown tablo kullanma.';
	if ( $action_type === 'examples' ) {
		$prompt = "Ders: {$title}\nParagraf: {$context}\n\nBu paragraftaki kuralı veya fikri tek cümlede sadeleştir; ardından birbirinden farklı 4 yeni İngilizce örnek ve Türkçe karşılıklarını ver. En sonda öğrencinin anlayıp anlamadığını ölçen tek bir kısa soru sor.";
	} else {
		$prompt = "Ders: {$title}\nParagraf: {$context}\nÖğrencinin sorusu: {$question}\n\nSoruyu doğrudan yanıtla. Gerekirse en fazla 3 kısa örnek ver ve yaygın bir hatayı belirt.";
	}

	$cache_key = 'ewt_help_' . md5( $action_type . '|' . $title . '|' . $context . '|' . $question );
	$answer    = get_transient( $cache_key );
	if ( ! is_string( $answer ) || $answer === '' ) {
		$key = get_option( 'ewt_youcom_api_key' );
		if ( ! $key ) {
			wp_send_json_error( array( 'message' => 'You.com API anahtarı henüz ayarlanmamış.' ), 503 );
		}
		$answer = ewt_youcom_express( $system . "\n\n" . $prompt, $key, true );
		if ( is_wp_error( $answer ) ) {
			error_log( 'EWT lesson assistant: ' . $answer->get_error_code() );
			wp_send_json_error( array( 'message' => 'Şu anda yanıt üretilemedi. Lütfen biraz sonra yeniden deneyin.' ), 502 );
		}
		$answer = sanitize_textarea_field( $answer );
		set_transient( $cache_key, $answer, DAY_IN_SECONDS );
		set_transient( $rate_key, $used + 1, HOUR_IN_SECONDS );
	}

	wp_send_json_success( array( 'answer' => $answer ) );
}
add_action( 'wp_ajax_ewt_lesson_assistant', 'ewt_ajax_lesson_assistant' );
add_action( 'wp_ajax_nopriv_ewt_lesson_assistant', 'ewt_ajax_lesson_assistant' );
